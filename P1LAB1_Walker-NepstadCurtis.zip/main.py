name = input()
print('Hello ' + name + ' and welcome to CS Online!')
