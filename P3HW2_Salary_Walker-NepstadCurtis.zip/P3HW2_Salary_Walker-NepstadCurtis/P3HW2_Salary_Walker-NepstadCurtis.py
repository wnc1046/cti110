# CTI-110
# P3HW2 - Salary
# Curtis Walker-Nepstad
# 11/1/22
#
# Define name variable with input
# Define hours worked with input
# Define pay rate with input
# Show divider
# Show employee name
# Define overtime
# Define overtime_pay
# If overtime over 0, overtime_pay = (overtime * 26.25)
# else overtime = 0
# reg_pay = hours worked * rate of pay
# gross_pay = reg_pay + overtime_pay
# Show 'Hours Worked  Pay Rate  OverTime  OverTime Pay  RegHour Pay  Gross Pay'
# Show Divider
# Show f'{hours:.2f} {pay_rate:15.2f} {overtime:10.2f} {overtime_pay:10.2f} {reg_pay:13.2f} {gross_pay:10.2f}'

name = input("Enter name of employee: ")
hours = int(input("Enter number of hours worked: "))
pay_rate = int(float(input("Enter employee's pay rate: ")))
print('-------------------------')
print('Employee name: ', name)
            
overtime = hours - 40
overtime_pay = (hours - 40)

if overtime > 0 :
    overtime_pay = float(overtime * 26.25)
else:
    overtime = 0

reg_pay = float(hours * pay_rate)
gross_pay = float(reg_pay + overtime_pay)

print('Hours Worked  Pay Rate  OverTime  OverTime Pay  RegHour Pay  Gross Pay')
print('-----------------------------------------------------------------------')
print(f'{hours:.2f} {pay_rate:15.2f} {overtime:10.2f} {overtime_pay:10.2f} {reg_pay:13.2f} {gross_pay:10.2f}')
            
