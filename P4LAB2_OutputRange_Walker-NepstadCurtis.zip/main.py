word = input()
stop_words = ["Done", "done", "d"]
while word not in stop_words:
    print(word[::-1])
    word = input()
