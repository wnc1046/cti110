# This program assigns a list of inputted grades as variables to a list, and then shows the lowest, highest, sum of, and average of the grades are.
# CTI-110
# P2HW2 - List
# Curtis Walker-Nepstad
# 10/8/22
#
###########################
# Input module_1
# Input module_2
# Input module_3
# Input module_4
# Input module_5
# Input module_6
# Set grades_list = [module_1, module_2, module_3, module_4, module_5, module_6]
# Display "--------Results--------"
# Display "The lowest test grade was:", min(grades_list)
# Display "The highest test grade was", max(grades_list)
# Display "The sum of the grades was:", sum(grades_list)
# Display "The average of the grades was:", sum(grades_list)/len(grades_list)
#

module_1 = int(float(input('Enter grade for module 1:')))
module_2 = int(float(input('Enter grade for module 2:')))
module_3 = int(float(input('Enter grade for module 3:')))
module_4 = int(float(input('Enter grade for module 4:')))
module_5 = int(float(input('Enter grade for module 5:')))
module_6 = int(float(input('Enter grade for module 6:')))
grades_list = [module_1, module_2, module_3, module_4, module_5, module_6]
print('\n --------Results--------')
print(f'{"The lowest test grade was:" : <15} {min(grades_list):.2f}')
print(f'{"The highest test grade was:" : <15} {max(grades_list):.2f}')
print(f'{"The sum of the grades was:" : <15} {sum(grades_list):.2f}')
print(f'{"The average of the grades was:" : <15} {sum(grades_list)/len(grades_list):.2f}')


