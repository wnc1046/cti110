''' Type your code here. '''

miles_per_gallon = float(input())
dollars_per_gallon = float(input())

gas_cost = dollars_per_gallon / miles_per_gallon

cost_1 = 20 * gas_cost
cost_2 = 75 * gas_cost
cost_3 = 500 * gas_cost

print(f'{cost_1:.2f} {cost_2:.2f} {cost_3:.2f}')


