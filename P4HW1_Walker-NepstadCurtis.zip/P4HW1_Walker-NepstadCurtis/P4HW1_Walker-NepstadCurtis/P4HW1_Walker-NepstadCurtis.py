# CTI-110
# P4HW1 - Score List
# Curtis Walker-Nepstad
#11/22/22
#
# Get number of scores
# Make scores list
# Make new score for each number in score_num
# Add inputted score number to scores
# Calculate smallest score
# Make copy of scores called scores_without_min
# Remove smallest score in scores_without_min
# Calculate average of scores
# Else if scores average is greater than or equal to 90, grade = A
# Else if scores average is greater than or equal to 80, grade = B
# Else if scores average is greater than or equal to 70, grade = C
# Else if scores average is greater than or equal to 60, grade = D
# Else grade = F
# Show --------Results--------
# Show Lowest Score : min_scores
# Show Modified List : scores_without_min
# Show Scores Average: scores_average
# Show Grade: grade
# Show -------------------------

score_num = int(input('How many scores do you want to enter? '))
scores = []

for x in range(1, score_num + 1):
    score = float(input('Enter score #' +str(x)+ ': '))
    while score < 0 or score > 100:
        print('INVALID Score entered!!!!')
        print('Score should be between 0 and 100')
        score = float(input('Enter score #' +str(x)+ ' again:'))
    scores.append(score)

min_scores = min(scores)
scores_without_min = scores
scores_without_min.remove(min_scores)
scores_average = sum(scores_without_min) / len(scores_without_min)


if scores_average >= 90:
    grade = 'A'
elif scores_average >= 80:
    grade = 'B'
elif scores_average >= 70:
    grade = 'C'
elif scores_average >= 60:
    grade = 'D'
else:
    grade = 'F'

print('\n',('-' * 8), 'Results',('-' * 8))
print(f'Lowest Score  : {min_scores:<10.2f}')
print('Modified List :', scores_without_min)
print(f'Scores Average: {scores_average:<10.2f}')
print('Grade',  ':', grade)
print('-' * 25)





    

    
