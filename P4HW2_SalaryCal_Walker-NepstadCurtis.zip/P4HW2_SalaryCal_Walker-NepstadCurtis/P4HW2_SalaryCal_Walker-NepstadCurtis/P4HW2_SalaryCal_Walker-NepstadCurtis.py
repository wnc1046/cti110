# CTI-110
# P4HW2 - Salary Calculator
# Curtis Walker-Nepstad
#
# Input employee name
# Define  employee_num
# Define total_overtime_pay
# Define total_reg_pay
# Define total_gross_pay
# while employee name is not none:
# add to employee_num
# enter hours_worked
# enter pay_rate
# if hours_worked is greater than 40:
# overtime = hours_worked - 40
# overtime_pay_rate = pay_rate * 1.5
# overtime_pay = overtime_hours * overtime_pay_rate
# else:
# overtime_hours = 0
# overtime_pay = 0
# reg_pay = hours_worked * pay_rate
# gross_pay = reg_pay + overtime_pay
# total_overtime_pay = total of all values entered for employee overtime_pay
# total_reg_pay = total of all values entered for emplyoee reg_pay
# total_gross_pay = total of all values entered for employee gross_pay
# print Hours Worked  Pay Rate  OverTime  OverTime Pay  RegHour Pay  Gross Pay
# print 76 -'s
# print hours_worked  pay_rate  overtime_hours  overtime_pay  reg_pay  gross_pay
# Enter another employees name to run the loop and enter their information again or enter 'None' to stop the loop
###################################################################################################################

employee_name = input("Enter employee's name or 'None' to terminate: ")
employee_num = 0
total_overtime_pay = 0
total_reg_pay = 0
total_gross_pay = 0

while employee_name != 'None':
    employee_num  += 1
    hours_worked = float(input(f'How many hours did {employee_name} work? '))
    pay_rate = float(input(f"What is {employee_name}'s pay rate? "))

    if hours_worked > 40 :
        overtime_hours = hours_worked - 40
        overtime_pay_rate = pay_rate * 1.5
        overtime_pay = overtime_hours * overtime_pay_rate
    else:
        overtime_hours = 0
        overtime_pay = 0

    reg_pay = float(hours_worked * pay_rate)
    gross_pay = float(reg_pay + overtime_pay)
    total_overtime_pay += overtime_pay
    total_reg_pay += reg_pay
    total_gross_pay += gross_pay

    print(f'{"Hours Worked":<10} {"Pay Rate":<12} {"OverTime":<10} {"OverTime Pay":<10} {"RegHour Pay":<10} {"Gross Pay":<10}')
    print('-' * 76)
    print(f'{hours_worked:<10.2f} {pay_rate:<12.2f} {overtime_hours:<10.2f} {overtime_pay:<12.2f} {reg_pay:<12.2f} {gross_pay:<10.2f}') 
    
    employee_name = input("Enter employee's name or 'None' to terminate: ")

    
print('Employee name: ')
print("Total number of employees entered:", employee_num)
print("Total amount paid for overtime:", '$',total_overtime_pay)
print("Total amount paid for regular hours:", '$',total_reg_pay)
print("Total amount paid in gross:", '$',total_gross_pay)
