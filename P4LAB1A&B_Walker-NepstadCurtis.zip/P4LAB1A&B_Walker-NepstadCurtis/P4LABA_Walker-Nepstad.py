import turtle
wn = turtle.Screen()
sqr = turtle.Turtle()
sqr.shape("square")
tri = turtle.Turtle()
tri.shape("triangle")
for x in range(4):
    sqr.forward(50)
    sqr.right(90)
    for i in range(3):
        tri.forward(100)
        tri.left(120)
    
