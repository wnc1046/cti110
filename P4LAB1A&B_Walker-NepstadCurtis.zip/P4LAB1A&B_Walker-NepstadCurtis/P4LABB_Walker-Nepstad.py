import turtle
wn = turtle.Screen()
c = turtle.Turtle()
w = turtle.Turtle()

c.backward(50)
c.left(90)
c.backward(100)
c.left(90)
c.backward(50)
c.right(180)
c.penup()

w.penup()
w.forward(100)
w.pendown()

for x in range(2):
    w.right(60)
    w.forward(100)
    w.left(120)
    w.forward(100)
    w.right(60)


